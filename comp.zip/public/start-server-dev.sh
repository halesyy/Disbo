export NODE_ENV=dev
DEBUG=app:* node app.js
