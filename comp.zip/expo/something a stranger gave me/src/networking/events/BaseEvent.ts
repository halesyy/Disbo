export default class BaseEvent {
    
    private data: any;

    constructor(data: any) {
        this.data = data;
    }

}