let Config = {

    "environment": {
        "debug": true,
        "main_container": "#habbo"
    },
    
    "connection": {
        "host": "138.68.108.17",
        "port": 30008
    },

    "navigator": {
        "title": "Hotel Navigator"
    }

};

export default Config;