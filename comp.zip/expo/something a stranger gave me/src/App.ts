import Habbo from './Habbo';

Habbo.Preload();

(<any>window).Habbo = Habbo;