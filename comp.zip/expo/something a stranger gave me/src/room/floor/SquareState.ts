enum SquareState {
    EMPTY = 0,
    OPEN = 1
}

export default SquareState;