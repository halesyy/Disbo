export default class FilesToPreload {
    public static Paths() {
        return [
            "room.tile.tile_b",
            "room.tile.tile_outline",
            "room.tile.tile_t",   
            "room.tile.stair_right",
            "room.tile.stair_left",
            "room.tile.stair_middle",
            "avatar.konquer",
            "avatar.1"
        ]
    }
}